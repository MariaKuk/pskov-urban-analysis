"""Run the preregistered A/B scenarios, then the exhaustive one-school search."""
import json
from pathlib import Path

import pandas as pd

from model import Engine, ROOT, RESULTS, digest, now, write_json


def main():
    engine = Engine()
    plan = ROOT/'analysis-plan.json'
    if not plan.exists():
        if (RESULTS/'search-600.json').exists():
            raise RuntimeError('Нельзя создавать предварительный выбор после автоматического поиска.')
        write_json(plan, {'recorded_at':now(),'status':'fixed_before_search',
            'decision':'Кварталы предложены агентом по исходным данным и приняты пользователем до автоматического поиска.',
            'user_reply':'Принять предложенные кварталы №127 и №295',
            'primary_metric':'Сокращение суммарного demand_left относительно исходного состояния, мест.',
            'scope':'Все 781 квартал транспортной области практики 2; 152 вне расчёта.',
            'tolerance':1e-7,'mode':'Exploratory: сценарное моделирование, не причинная оценка.',
            'A':{'additions':{'127':600},'reason':'Квартал №127: исходный дефицит 478 мест, школ нет. Размещаем большую школу в наиболее дефицитном квартале; остаток вместимости может обслужить соседей.'},
            'B':{'additions':{'127':300,'295':300},'reason':'Кварталы №127 и №295: исходный дефицит 478 и 391 место, существующих школ нет. Распределяем 600 мест между двумя кварталами с большой неудовлетворённой потребностью.'},
            'hypothesis':'Все сценарии могут дать одинаковое сокращение общего дефицита, но разное распределение мест между кварталами. Результат заранее неизвестен.',
            'source_baseline_sha256':digest(ROOT/'data/practice2-baseline.csv')})
    spec = json.loads(plan.read_text(encoding='utf-8'))
    scenarios = []
    for key in ['A','B']:
        result = engine.result(spec[key]['additions'])
        result.update(name=key,reason=spec[key]['reason'])
        scenarios.append(result)
        write_json(RESULTS/f'scenario-{key}.json',result)
        pd.DataFrame(result['rows']).to_csv(RESULTS/f'scenario-{key}.csv',index=False)
        print(key,result['summary'],flush=True)
    def progress(s):
        if s['checked'] % 50 == 0 or s['checked'] == s['total']:
            print(f"Поиск: {s['checked']}/{s['total']}, ошибок: {s['failed']}",flush=True)
    search = engine.search(600,progress)
    if not search['complete']:
        raise RuntimeError('Перебор неполон: нельзя делать вывод о лучшем квартале.')
    chosen = min(search['best_ids'])
    c = engine.result({chosen:600})
    c.update(name='C',reason=f'Один из равноценных лучших кварталов ({len(search["best_ids"])}). Для иллюстрации взят наименьший ID; это не градостроительный приоритет.')
    scenarios.append(c)
    write_json(RESULTS/'scenario-C.json',c)
    pd.DataFrame(c['rows']).to_csv(RESULTS/'scenario-C.csv',index=False)
    result = {'completed_at':now(),'fingerprint':engine.fingerprint,'analysis_plan_sha256':digest(plan),
        'baseline':engine.base_summary,'scenarios':scenarios,'auto_selected_id':chosen,
        'auto_best_ids':search['best_ids'],'manual_A_is_tied_best':127 in search['best_ids'],
        'search_checked':search['checked'],'search_failed':search['failed']}
    write_json(RESULTS/'experiment.json',result)
    pd.DataFrame([{'scenario':'Исходное',**engine.base_summary,'added_capacity':0,'reduction':0}]+
        [{'scenario':s['name'],**s['summary']} for s in scenarios]).to_csv(RESULTS/'comparison.csv',index=False)
    print(json.dumps({'complete':True,'best_count':len(search['best_ids']),'chosen':chosen,
                      'scenarios':[{k:s[k] for k in ['name','summary']} for s in scenarios]},ensure_ascii=False),flush=True)


if __name__ == '__main__':
    main()
