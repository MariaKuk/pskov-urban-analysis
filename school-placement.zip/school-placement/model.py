"""Practice 3: the unchanged BlocksNet competitive allocation method from practice 2."""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
import math
import os
import shutil
import subprocess
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd
import pulp
from blocksnet.analysis.provision import competitive_provision
from loguru import logger

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
RESULTS = ROOT / 'results'
SOLVER_LOCK = threading.RLock()
TOL = 1e-7
logger.remove()


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    tmp.replace(path)


def records(frame):
    return json.loads(frame.reset_index(names='block_id').to_json(orient='records'))


class CheckedCBC(pulp.COIN_CMD):
    def actualSolve(self, problem, **kwargs):
        # PuLP 2.7 splits CBC arguments on spaces. Relative UUID filenames avoid
        # broken TEMP paths such as C:\Users\Student Name\... on Windows.
        self.tmpDir = ''
        result = super().actualSolve(problem, **kwargs)
        if problem.status != pulp.LpStatusOptimal:
            raise RuntimeError('CBC: решение не оптимально: ' + pulp.LpStatus[problem.status])
        return result


class Engine:
    def __init__(self):
        self.manifest = json.loads((DATA / 'manifest.json').read_text(encoding='utf-8'))
        for name, expected in self.manifest['packaged_sha256'].items():
            if digest(DATA / name) != expected:
                raise RuntimeError('Изменён входной файл: ' + name + '. Повторите prepare.py.')
        if importlib.metadata.version('blocksnet') != '1.0.0a9':
            raise RuntimeError('Нужна совместимая версия BlocksNet 1.0.0a9 из практики 2.')
        self.inputs = pd.read_csv(DATA / 'blocks.csv', index_col='block_id')
        with np.load(DATA / 'matrix.npz', allow_pickle=False) as z:
            self.ids = z['block_ids'].astype(int)
            self.matrix = pd.DataFrame(z['minutes'], index=self.ids, columns=self.ids)
        if not np.array_equal(self.inputs.index, self.ids):
            raise RuntimeError('Идентификаторы кварталов не соответствуют матрице.')
        a = self.matrix.to_numpy()
        if (not np.isfinite(a).all() or (a < 0).any() or not np.all(a.diagonal() == 0)):
            raise RuntimeError('Некорректная матрица времени.')
        if not self.inputs.index.is_unique or (self.inputs[['population', 'capacity']] < 0).any().any():
            raise RuntimeError('Некорректные входные показатели.')
        self.cbc = None
        for candidate in [shutil.which('cbc'), '/opt/homebrew/bin/cbc',
                          '/usr/local/bin/cbc', pulp.PULP_CBC_CMD().path]:
            if not candidate or not Path(candidate).is_file():
                continue
            try:
                subprocess.run([candidate, '-stop'], check=True, capture_output=True, timeout=15)
            except (OSError, subprocess.SubprocessError):
                continue
            self.cbc = str(candidate)
            break
        if not self.cbc:
            raise RuntimeError('Не найден CBC. См. README.md.')
        self.config = self.manifest['parameters']
        self.fingerprint = hashlib.sha256(json.dumps({
            'data': self.manifest['packaged_sha256'], 'parameters': self.config,
            'model': digest(__file__), 'versions': {k: importlib.metadata.version(k)
                for k in ['blocksnet','numpy','pandas','pulp']}, 'cbc': digest(self.cbc)
        }, sort_keys=True).encode()).hexdigest()
        self.baseline, self.base_links = self.calculate({})
        saved = pd.read_csv(DATA / 'practice2-baseline.csv', index_col='block_id')
        if not self.baseline.index.equals(saved.index) or not np.allclose(
                self.baseline[saved.columns], saved, atol=TOL, rtol=0, equal_nan=True):
            raise RuntimeError('Расчёт не воспроизводит исходный результат практики 2.')
        self.base_summary = self.summary(self.baseline)
        self.geometry = json.loads((DATA / 'blocks.geojson').read_text(encoding='utf-8'))

    def normalize(self, additions):
        if not isinstance(additions, dict):
            raise ValueError('Сценарий должен содержать кварталы и число мест.')
        clean = {}
        for raw_id, value in additions.items():
            try:
                block_id = int(raw_id)
            except (ValueError, TypeError):
                raise ValueError('Некорректный номер квартала.') from None
            if str(block_id) != str(raw_id) or block_id not in self.inputs.index:
                raise ValueError('Квартал отсутствует в расчётной территории.')
            if isinstance(value, bool) or not isinstance(value, (int, np.integer)) or value <= 0:
                raise ValueError('Вместимость должна быть положительным целым числом мест.')
            if value > 1_000_000:
                raise ValueError('Слишком большая вместимость: предел приложения — 1 000 000 мест.')
            clean[block_id] = int(value)
        return dict(sorted(clean.items()))

    def calculate(self, additions):
        clean = self.normalize(additions)
        inputs = self.inputs[['population','capacity']].copy(deep=True)
        for block_id, places in clean.items():
            inputs.loc[block_id, 'capacity'] += places
        with SOLVER_LOCK, patch('blocksnet.analysis.provision.competitive.core.PULP_CBC_CMD',
                               new=lambda **kw: CheckedCBC(path=self.cbc,
                                   threads=0 if os.name == 'nt' else 1, **kw)):
            out, links = competitive_provision(inputs, self.matrix,
                accessibility=self.config['accessibility_minutes'], demand=self.config['places_per_1000'],
                self_supply=True, max_depth=1)
        self.validate(out, links, inputs)
        return out, links

    def validate(self, out, links, inputs):
        # Reconstruct allocations independently from actual links and self-supply.
        expected_demand = np.ceil(inputs.population / 1000 * self.config['places_per_1000'])
        assert np.array_equal(out.demand, expected_demand), 'Потребность изменилась'
        own = np.minimum(out.demand, out.capacity)
        served = pd.Series(own, index=out.index, dtype=float)
        used = served.copy()
        if not links.empty:
            for (source, target), row in links.iterrows():
                value = row['value']
                assert value >= 0 and abs(value - round(value)) < TOL
                assert self.matrix.loc[source, target] <= self.config['accessibility_minutes']
                served.loc[source] += value
                used.loc[target] += value
        assert np.allclose(served, out.demand_within, atol=TOL, rtol=0)
        assert np.allclose(out.demand - served, out.demand_left, atol=TOL, rtol=0)
        assert np.allclose(out.capacity - used, out.capacity_left, atol=TOL, rtol=0)
        assert np.all(served <= out.demand + TOL) and np.all(used <= out.capacity + TOL)
        assert np.all(out[['demand_left','capacity_left']] >= -TOL)
        assert out.demand_without.sum() == 0
        assert np.allclose(out.capacity, inputs.capacity, atol=TOL, rtol=0)

    def summary(self, out):
        demand = int(out.demand.sum())
        return {'demand': demand, 'capacity': int(out.capacity.sum()),
                'served': int(out.demand_within.sum()), 'deficit': int(out.demand_left.sum()),
                'provision_pct': float(out.demand_within.sum()/demand*100) if demand else None}

    def result(self, additions, out=None):
        clean = self.normalize(additions)
        if out is None:
            out, _ = self.calculate(clean)
        table = out.copy()
        table['population'] = self.inputs.population
        table['baseline_capacity'] = self.baseline.capacity
        table['baseline_served'] = self.baseline.demand_within
        table['baseline_deficit'] = self.baseline.demand_left
        table['baseline_provision'] = self.baseline.provision_strong
        table['added_capacity'] = out.capacity - self.baseline.capacity
        table['change_served'] = out.demand_within - self.baseline.demand_within
        table['change_pp'] = (out.provision_strong - self.baseline.provision_strong) * 100
        summary = self.summary(out)
        summary.update(added_capacity=sum(clean.values()),
                       reduction=self.base_summary['deficit']-summary['deficit'],
                       improved_blocks=int((table.change_served > 0).sum()),
                       worsened_blocks=int((table.change_served < 0).sum()),
                       deficit_blocks=int((out.demand_left > 0).sum()))
        return {'additions': clean, 'summary': summary, 'rows': records(table),
                'fingerprint': self.fingerprint, 'computed_at': now()}

    def search(self, capacity, progress=None, force=False):
        self.normalize({int(self.ids[0]): capacity})
        path = RESULTS / f'search-{capacity}.json'
        if path.exists() and not force:
            old = json.loads(path.read_text(encoding='utf-8'))
            if old.get('fingerprint') == self.fingerprint and old.get('complete'):
                old['from_cache'] = True
                if progress:
                    progress(old)
                return old
        started = now()
        state = {'capacity': capacity, 'total': len(self.ids), 'checked': 0, 'successful': 0,
                 'failed': 0, 'complete': False, 'rows': [], 'best_ids': [], 'from_cache': False,
                 'fingerprint': self.fingerprint, 'started_at': started}
        allocations = []
        for block_id in self.ids:
            tick = time.monotonic()
            try:
                out, _ = self.calculate({int(block_id): capacity})
                summary = self.summary(out)
                row = {'block_id': int(block_id), 'status': 'ok', **summary,
                       'reduction': self.base_summary['deficit']-summary['deficit']}
                allocations.append(out.demand_within.to_numpy(dtype=np.int32))
                state['successful'] += 1
            except Exception as exc:
                row = {'block_id': int(block_id), 'status': 'error', 'error': str(exc)}
                allocations.append(np.full(len(self.ids), -1, dtype=np.int32))
                state['failed'] += 1
            row['seconds'] = round(time.monotonic()-tick, 3)
            state['rows'].append(row)
            state['checked'] += 1
            if progress:
                progress({k:v for k,v in state.items() if k != 'rows'})
        state['rows'].sort(key=lambda r:(r['status'] != 'ok', -r.get('reduction', -10**9), r['block_id']))
        state['complete'] = state['checked'] == len(self.ids) and state['failed'] == 0
        good = [r for r in state['rows'] if r['status'] == 'ok']
        if good:
            state['best_observed_reduction'] = good[0]['reduction']
            state['best_observed_ids'] = [r['block_id'] for r in good
                if abs(r['reduction'] - good[0]['reduction']) <= TOL]
            if state['complete']:
                state['best_ids'] = state['best_observed_ids']
        state['finished_at'] = now()
        RESULTS.mkdir(exist_ok=True)
        np.savez_compressed(RESULTS / f'search-{capacity}-allocations.npz',
                            candidates=self.ids, block_ids=self.ids, served=np.stack(allocations))
        state['allocations_sha256'] = digest(RESULTS / f'search-{capacity}-allocations.npz')
        write_json(path, state)
        pd.DataFrame(state['rows']).to_csv(RESULTS / f'search-{capacity}.csv', index=False)
        if progress:
            progress(state)
        return state
