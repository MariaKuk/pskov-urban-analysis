"""Separate review of saved experiment, full search, provenance and central claims."""
import json
from datetime import datetime

import numpy as np
import pandas as pd

from model import Engine, ROOT, RESULTS, digest, now, write_json


def main():
    engine=Engine()
    checks=[]
    def check(label,passed,details=''):
        checks.append({'check':label,'passed':bool(passed),'details':details})
        if not passed:
            write_json(ROOT/'audit/experiment-audit.json',{'status':'FAIL','checks':checks})
            raise RuntimeError(label)
    s=json.loads((RESULTS/'search-600.json').read_text(encoding='utf-8'))
    exp=json.loads((RESULTS/'experiment.json').read_text(encoding='utf-8'))
    plan=json.loads((ROOT/'analysis-plan.json').read_text(encoding='utf-8'))
    check('Ручной выбор записан до начала перебора',datetime.fromisoformat(plan['recorded_at'])<datetime.fromisoformat(s['started_at']))
    check('Результаты соответствуют текущей модели',s['fingerprint']==exp['fingerprint']==engine.fingerprint)
    rows=s['rows']; lookup={r['block_id']:r for r in rows}
    check('Каждый квартал проверен ровно один раз',len(rows)==len(engine.ids)==len(lookup) and set(lookup)==set(engine.ids))
    check('Нет пропущенных или ошибочных вариантов',s['complete'] and s['checked']==781 and s['failed']==0 and all(r['status']=='ok' for r in rows))
    check('Рейтинг упорядочен по сокращению дефицита',all(rows[i]['reduction']>=rows[i+1]['reduction'] for i in range(len(rows)-1)))
    check('Все варианты имеют ровно 600 дополнительных мест',all(r['capacity']==engine.base_summary['capacity']+600 and r['demand']==22766 for r in rows))
    allocation_file=RESULTS/'search-600-allocations.npz'
    check('Контрольная сумма всех распределений совпадает',digest(allocation_file)==s['allocations_sha256'])
    with np.load(allocation_file,allow_pickle=False) as z:
        ids=z['candidates']; served=z['served']; columns=z['block_ids']
    check('Матрица распределений охватывает каждый вариант и квартал',np.array_equal(ids,engine.ids) and np.array_equal(columns,engine.ids) and served.shape==(781,781))
    check('Потребность не превышена ни в одном из 609961 значений',np.all(served>=0) and np.all(served<=engine.baseline.demand.to_numpy()[None,:]))
    deficits=engine.base_summary['demand']-served.sum(axis=1)
    check('Итоги всех вариантов независимо восстановлены из кварталов',all(int(deficits[k])==lookup[int(i)]['deficit'] for k,i in enumerate(ids)))
    gains=engine.base_summary['deficit']-deficits
    expected_best=sorted(int(i) for i,g in zip(ids,gains) if g==gains.max())
    check('Все равноценные лучшие варианты перечислены',sorted(s['best_ids'])==expected_best)
    # This bound applies because baseline capacity is completely used, not to every possible weighted model.
    check('Сокращение не больше добавленной вместимости',int(gains.max())<=600,{'max':int(gains.max()),'min':int(gains.min())})
    samples=sorted({127,295,exp['auto_selected_id'],rows[-1]['block_id'],int(ids[len(ids)//2])})
    repeated=[]
    for i in samples:
        out,_=engine.calculate({i:600})
        pos=int(np.where(ids==i)[0][0])
        ok=np.array_equal(out.demand_within.to_numpy(),served[pos])
        check(f'Ручной расчёт квартала {i} совпадает с полным поиском',ok)
        repeated.append(i)
    for scenario in exp['scenarios']:
        out,_=engine.calculate(scenario['additions'])
        fresh=engine.result(scenario['additions'],out)
        check('Повторение сценария '+scenario['name'],fresh['rows']==scenario['rows'] and fresh['summary']==scenario['summary'])
        exported=pd.read_csv(RESULTS/f"scenario-{scenario['name']}.csv")
        check('CSV соответствует сценарию '+scenario['name'],np.array_equal(exported.demand_left,out.demand_left) and exported.block_id.tolist()==out.index.tolist())
    snapshots=json.loads((ROOT/'audit/practice2-source-hashes.json').read_text(encoding='utf-8'))['files']
    check('Все исходные файлы практики 2 неизменны',all(digest(ROOT.parent/p)==h for p,h in snapshots.items()),{'files':len(snapshots)})
    test_result=json.loads((ROOT/'audit/model-api-tests.json').read_text(encoding='utf-8'))
    check('Автоматические тесты модели и API пройдены',test_result['passed'],{'tests':test_result['tests']})
    independent=json.loads((ROOT/'audit/independent-lp.json').read_text(encoding='utf-8'))
    check('Отдельный пересчёт SciPy подтверждает взвешенный оптимум',all(c['passed'] for c in independent['checks']))
    # Diagnostic sensitivity only; these values do not replace the practice 2 baseline.
    sensitivity=[]
    for minutes in [10,15,20]:
        engine.config['accessibility_minutes']=minutes
        original,_=engine.calculate({})
        base=engine.summary(original)
        for name, additions in [('A',{127:600}),('B',{127:300,295:300})]:
            out,_=engine.calculate(additions)
            summary=engine.summary(out)
            sensitivity.append({'threshold_minutes':minutes,'scenario':name,
                'baseline_deficit':base['deficit'],'scenario_deficit':summary['deficit'],
                'reduction':base['deficit']-summary['deficit']})
    engine.config['accessibility_minutes']=15
    write_json(ROOT/'audit/sensitivity.json',{'purpose':'Диагностическая чувствительность ручных сценариев; не новый автоматический поиск.','rows':sensitivity})
    review={'date':now(),'status':'PASS_WITH_LIMITATIONS','reviewer':'Отдельный проход того же агента; не внешняя независимая экспертиза.',
        'checks':checks,'sample_repeats':samples,'best_count':len(expected_best),'best_ids':expected_best,
        'limitations':engine.manifest['limitations'],'not_verified':['Наличие пригодных земельных участков','Фактическая численность населения и вместимость школ','Запуск на другой ОС'],
        'artifact_sha256':{str(p.relative_to(ROOT)):digest(p) for p in [ROOT/'model.py',ROOT/'server.py',ROOT/'web/app.js',RESULTS/'experiment.json',RESULTS/'search-600.json']}}
    write_json(ROOT/'audit/experiment-audit.json',review)
    print(json.dumps({'status':review['status'],'checks':len(checks),'best_count':len(expected_best),'min_reduction':int(gains.min()),'max_reduction':int(gains.max()),'samples':samples},ensure_ascii=False))


if __name__=='__main__':
    main()
