"""Start locally and open a browser only after the model and socket are ready."""
import argparse
import webbrowser
from pathlib import Path
import os

from server import make_server


if __name__ == '__main__':
    os.chdir(Path(__file__).resolve().parent)
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=8766)
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    server = make_server(args.port)
    address = f'http://127.0.0.1:{server.server_port}/'
    print(f'Open {address} (Ctrl+C to stop)', flush=True)
    if not args.no_browser:
        webbrowser.open(address)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
