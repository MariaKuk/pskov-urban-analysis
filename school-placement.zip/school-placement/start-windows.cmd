@echo off
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"
if not exist ".venv\Scripts\python.exe" (
  echo Run setup-windows.cmd first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -X utf8 launch.py %*
if errorlevel 1 (
  echo The application stopped with an error. Read the message above.
  pause
  exit /b 1
)
