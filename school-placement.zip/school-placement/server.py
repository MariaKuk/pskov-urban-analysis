"""Local-only HTTP application. No API keys, external models or paid services."""
import argparse
import json
import mimetypes
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

from model import Engine, ROOT, RESULTS


def make_server(port=8766):
    engine = Engine()
    executor = ThreadPoolExecutor(max_workers=1)
    jobs = {}
    lock = threading.Lock()
    public = ROOT/'web'

    def run_search(job_id, capacity, force):
        def progress(value):
            with lock:
                jobs[job_id] = {'state':'running', **value}
        try:
            result = engine.search(capacity, progress, force)
            with lock:
                jobs[job_id] = {'state':'finished', **result}
        except Exception as exc:
            with lock:
                jobs[job_id] = {'state':'error','error':str(exc)}

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def reply(self, data, status=200, content_type='application/json; charset=utf-8'):
            body = data if isinstance(data, bytes) else json.dumps(data, ensure_ascii=False, allow_nan=False).encode()
            self.send_response(status)
            self.send_header('Content-Type',content_type)
            self.send_header('Content-Length',str(len(body)))
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            route = urlparse(self.path).path
            if route == '/api/bootstrap':
                return self.reply({'manifest':engine.manifest,'baseline':engine.result({},engine.baseline),
                    'geometry':engine.geometry,'fingerprint':engine.fingerprint})
            if route.startswith('/api/search/'):
                with lock:
                    job = jobs.get(route.rsplit('/',1)[-1])
                return self.reply(job or {'error':'Расчёт не найден.'},200 if job else 404)
            if route == '/api/experiment':
                path = RESULTS/'experiment.json'
                if not path.exists():
                    return self.reply({'scenarios':[]})
                value = json.loads(path.read_text())
                if value.get('fingerprint') != engine.fingerprint:
                    return self.reply({'scenarios':[], 'warning':'Эксперимент нужно пересчитать после изменения модели.'})
                return self.reply(value)
            target = (public / ('index.html' if route == '/' else route.lstrip('/'))).resolve()
            if target.is_relative_to(public) and target.is_file():
                return self.reply(target.read_bytes(),content_type=(mimetypes.guess_type(str(target))[0] or 'application/octet-stream'))
            return self.reply({'error':'Страница не найдена.'},404)

        def do_POST(self):
            origin = self.headers.get('Origin')
            if origin and origin not in [f'http://127.0.0.1:{self.server.server_port}',f'http://localhost:{self.server.server_port}']:
                return self.reply({'error':'Разрешены только запросы локального приложения.'},403)
            if not self.headers.get('Content-Type','').startswith('application/json'):
                return self.reply({'error':'Ожидается JSON.'},415)
            try:
                size = int(self.headers.get('Content-Length','0'))
                if size <= 0 or size > 100_000:
                    raise ValueError('Некорректный размер запроса.')
                body = json.loads(self.rfile.read(size))
                if not isinstance(body,dict):
                    raise ValueError('Ожидается объект JSON.')
                if self.path == '/api/scenario':
                    return self.reply(engine.result(body.get('additions',{})))
                if self.path == '/api/search':
                    capacity = body.get('capacity')
                    engine.normalize({int(engine.ids[0]):capacity})
                    force = body.get('force',False)
                    if not isinstance(force,bool):
                        raise ValueError('Некорректный параметр повторного расчёта.')
                    with lock:
                        if any(j['state'] in ['running','queued'] for j in jobs.values()):
                            return self.reply({'error':'Поиск уже выполняется. Дождитесь завершения.'},409)
                        job_id = uuid.uuid4().hex
                        jobs[job_id] = {'state':'queued','checked':0,'total':len(engine.ids),'failed':0}
                    executor.submit(run_search,job_id,capacity,force)
                    return self.reply({'job_id':job_id},202)
                return self.reply({'error':'Действие не найдено.'},404)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                return self.reply({'error':str(exc)},400)
            except Exception as exc:
                return self.reply({'error':'Расчёт не выполнен: '+str(exc)},500)

    server = ThreadingHTTPServer(('127.0.0.1',port),Handler)
    server.engine = engine
    return server


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port',type=int,default=8766)
    args = parser.parse_args()
    server = make_server(args.port)
    print(f'Приложение: http://127.0.0.1:{server.server_port}',flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.server_close()
