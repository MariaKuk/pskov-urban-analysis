"""Prepare read-only copies and stage 1–3 evidence from the existing practice 2."""
import importlib.metadata
import json
import platform
import shutil
from pathlib import Path

import numpy as np
import pandas as pd

from model import DATA, ROOT, RESULTS, Engine, digest, now, write_json

PROJECT = ROOT.parent
checks = []


def check(name, condition, details=''):
    checks.append({'check': name, 'passed': bool(condition), 'details': details})
    if not condition:
        raise RuntimeError(name + ': ' + str(details))


def main():
    DATA.mkdir(exist_ok=True)
    RESULTS.mkdir(exist_ok=True)
    audit = ROOT / 'audit'
    audit.mkdir(exist_ok=True)
    paths = [p for d in ['data/pskov','results/pskov'] for p in (PROJECT/d).rglob('*') if p.is_file()]
    paths += [PROJECT/'tools/notebook_sources/pskov.py',PROJECT/'examples/pskov.ipynb', PROJECT/'dashboard.html']
    source_hashes = {str(p.relative_to(PROJECT)): digest(p) for p in sorted(paths)}
    write_json(audit/'practice2-source-hashes.json', {'recorded_at':now(), 'files':source_hashes})
    metrics = pd.read_csv(PROJECT/'results/pskov/blocks_metrics.csv', index_col='block_id')
    prov = pd.read_csv(PROJECT/'results/pskov/school_provision.csv', index_col='block_id')
    with np.load(PROJECT/'data/pskov/processed/accessibility_matrix.npz', allow_pickle=False) as z:
        ids, minutes = z['block_ids'], z['minutes']
    csv_mx = pd.read_csv(PROJECT/'results/pskov/accessibility_matrix.csv', index_col='block_id')
    check('Уникальные идентификаторы кварталов', metrics.index.is_unique and len(np.unique(ids)) == len(ids))
    check('Матрица: строки, столбцы и порядок', np.array_equal(csv_mx.index, ids)
          and np.array_equal(csv_mx.columns.astype(int), ids) and np.allclose(csv_mx, minutes))
    check('Кварталы исходного расчёта совпадают с матрицей', np.array_equal(prov.index, ids))
    check('Матрица конечна, неотрицательна, диагональ нулевая', minutes.shape == (len(ids),len(ids))
          and np.isfinite(minutes).all() and (minutes >= 0).all() and (minutes.diagonal() == 0).all())
    check('Область соответствует практике 2', set(metrics.index[metrics.transport_covered]) == set(ids))
    inputs = metrics.loc[ids,['building_population','school_capacity']].rename(
        columns={'building_population':'population','school_capacity':'capacity'})
    check('Нет пропусков/отрицательных значений населения и вместимости',
          not inputs.isna().any().any() and (inputs >= 0).all().all())
    inputs.to_csv(DATA/'blocks.csv', index_label='block_id')
    shutil.copyfile(PROJECT/'data/pskov/processed/accessibility_matrix.npz', DATA/'matrix.npz')
    shutil.copyfile(PROJECT/'results/pskov/school_provision.csv', DATA/'practice2-baseline.csv')
    geo = json.loads((PROJECT/'results/pskov/blocks_metrics.geojson').read_text(encoding='utf-8'))
    for feature in geo['features']:
        p = feature['properties']; block_id = int(p['row_id'])
        feature['properties'] = {'block_id': block_id, 'covered':block_id in set(ids),
            'population': int(p['building_population']), 'capacity':int(p['school_capacity']),
            'exclusion': p['transport_exclusion']}
    write_json(DATA/'blocks.geojson', geo)
    origin_manifest = json.loads((PROJECT/'results/pskov/manifest.json').read_text(encoding='utf-8'))
    manifest = {'created_at':now(), 'scope':{'city':'Псков','modeled_blocks':len(ids),
        'context_blocks':len(metrics),'excluded_blocks':len(metrics)-len(ids),
        'rule':'Ближайший узел исходного графа входит в главную сильносвязную компоненту; привязка не далее 1000 м.',
        'user_decision':'2026-11-24: продолжить практику 3 для 781 квартала, сохранив метод практики 2.',
        'exclusion_counts':metrics.loc[~metrics.transport_covered,'transport_exclusion'].value_counts().to_dict()},
        'parameters':{'places_per_1000':120,'accessibility_minutes':15,'self_supply':True,'max_depth':1,
                      'graph_mode':'drive','connector_kmh':5},
        'sources':{'assignment':'https://mvin8.github.io/ai-technologies-in-urbanism/content/practice/practice-03.html',
            'osm':'https://www.openstreetmap.org/copyright','osm_date':'2026-11-22',
            'graph':'https://doi.org/10.7910/DVN/KA5HJ3','graph_member':origin_manifest['graph_member'],
            'graph_publication_year':2025},
        'limitations':['781 из 933 кварталов; выводы не относятся ко всему Пскову.',
            'Население расчётное; вместимость 40 из 41 школьного объекта города восстановлена по модели.',
            'Автомобильный граф и условный порог 15 минут не проверяют нормы пешей доступности.',
            'Квартал — единица сравнения; свободный участок и возможность строительства не проверяются.',
            'При перераспределении мест обеспеченность отдельных кварталов может снижаться.'],
        'packaged_sha256':{name:digest(DATA/name) for name in ['blocks.csv','matrix.npz','practice2-baseline.csv','blocks.geojson']}}
    write_json(DATA/'manifest.json', manifest)
    engine = Engine()
    check('Воспроизведение всех значений практики 2', True, engine.base_summary)
    check('Вместимость соответствует исходной', int(inputs.capacity.sum()) == engine.base_summary['capacity'])
    check('Неизменность исходных файлов', all(digest(PROJECT/p) == h for p,h in source_hashes.items()))
    write_json(RESULTS/'baseline.json', engine.result({}, engine.baseline))
    write_json(audit/'stages-1-3.json', {'date':now(),'status':'PASS_WITH_SCOPE_LIMITATION',
        'checks':checks,'scope':manifest['scope'],'baseline':engine.base_summary,
        'environment':{'python':platform.python_version(),'machine':platform.machine(),
                       'packages':{n:importlib.metadata.version(n) for n in ['blocksnet','numpy','pandas','pulp','scipy']}}})
    print(json.dumps({'status':'PASS','checks':len(checks),'baseline':engine.base_summary}, ensure_ascii=False))


if __name__ == '__main__':
    main()
