#!/bin/zsh
set -eu
cd "$(dirname "$0")"
if [[ -x ../.venv/bin/python ]]; then
  exec ../.venv/bin/python server.py
elif [[ -x .venv/bin/python ]]; then
  exec .venv/bin/python server.py
else
  print 'Сначала настройте Python 3.12 по инструкции README.md.'
  read 'reply?Нажмите Enter, чтобы закрыть окно.'
  exit 1
fi
