@echo off
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"
if exist ".venv\Scripts\python.exe" goto install
py -3.12 -c "import struct; assert struct.calcsize('P') == 8" >nul 2>&1
if errorlevel 1 (
  echo Install Python 3.12 64-bit from https://www.python.org/downloads/windows/
  echo Include the Python launcher during installation, then run this file again.
  goto failed
)
py -3.12 -m venv .venv
if errorlevel 1 goto failed
:install
".venv\Scripts\python.exe" -X utf8 -m pip install -r requirements.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -X utf8 windows-check.py
if errorlevel 1 goto failed
echo Preparing scenarios and all 781 placements. This can take several minutes.
".venv\Scripts\python.exe" -X utf8 experiment.py
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -X utf8 windows-results-check.py
if errorlevel 1 goto failed
echo Setup and baseline calculation passed. Open start-windows.cmd.
if not defined CI pause
exit /b 0
:failed
echo Setup failed. Read the error above; the application has not been verified.
if not defined CI pause
exit /b 1
