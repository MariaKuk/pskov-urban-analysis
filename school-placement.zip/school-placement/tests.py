"""Executable checks of model contracts and the local HTTP API (unittest, stdlib)."""
import json
import threading
import tempfile
import unittest
import urllib.error
import urllib.request
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

from model import Engine, ROOT, digest, now, write_json
from server import make_server


class ModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.engine = Engine()

    def test_invalid_input(self):
        for val in [0,-1,1.5,True,'600',None,1000001]:
            with self.subTest(value=val), self.assertRaises(ValueError):
                self.engine.result({'127':val})
        for key in ['0','999999','127.0','abc']:
            with self.subTest(key=key), self.assertRaises(ValueError):
                self.engine.result({key:600})

    def test_scenario_isolation_and_capacity(self):
        e=self.engine
        inputs_before=e.inputs.copy(deep=True)
        matrix_before=e.matrix.copy(deep=True)
        first=e.result({127:600})
        second=e.result({127:300,295:300})
        third=e.result({127:600})
        self.assertEqual(first['rows'],third['rows'])
        for s in [first,second]:
            self.assertEqual(s['summary']['added_capacity'],600)
            self.assertEqual(s['summary']['capacity'],10715)
            self.assertEqual(s['summary']['demand'],22766)
            # For this baseline ALL capacity is used: no newly freed old capacity exists.
            self.assertLessEqual(s['summary']['reduction'],600)
            self.assertGreaterEqual(s['summary']['reduction'],0)
        self.assertTrue(e.inputs.equals(inputs_before))
        self.assertTrue(e.matrix.equals(matrix_before))
        reset,_=e.calculate({})
        self.assertTrue(reset.equals(e.baseline))

    def test_zero_demand_is_undefined(self):
        e=self.engine
        self.assertEqual(int((e.baseline.demand==0).sum()),459)
        for r in e.result({},e.baseline)['rows']:
            if r['demand']==0:
                self.assertIsNone(r['provision_strong'])
                self.assertIsNone(r['change_pp'])

    def test_independent_lp_objective(self):
        """Build transportation LP independently with SciPy; compare weighted optimum.

        The network constraint matrix is totally unimodular with integer RHS:
        its continuous optimum equals the integer optimum. Allocations may tie.
        """
        e=self.engine
        evidence=[]
        for additions in [{},{127:600},{127:300,295:300}]:
            out,links=e.calculate(additions)
            demand=out.demand.to_numpy(); capacity=out.capacity.to_numpy()
            own=np.minimum(demand,capacity)
            dl=demand-own; cl=capacity-own
            src,dst=np.where((dl[:,None]>0)&(cl[None,:]>0)&(e.matrix.to_numpy()<=15))
            weights=dl[src]*cl[dst]/(e.matrix.to_numpy()[src,dst]+1)
            n=len(demand); m=len(src)
            constraints=coo_matrix((np.ones(m*2),(np.r_[src,n+dst],np.r_[np.arange(m),np.arange(m)])),shape=(2*n,m)).tocsr()
            result=linprog(-weights,A_ub=constraints,b_ub=np.r_[dl,cl],bounds=(0,None),method='highs')
            self.assertTrue(result.success,result.message)
            pos={int(k):i for i,k in enumerate(e.ids)}
            actual=sum(dl[pos[i]]*cl[pos[j]]/(float(e.matrix.loc[i,j])+1)*r['value'] for (i,j),r in links.iterrows())
            self.assertAlmostEqual(actual,-result.fun,delta=max(1,abs(result.fun))*1e-7)
            evidence.append({'additions':additions,'cbc_objective':actual,'scipy_objective':-result.fun,'passed':True})
        write_json(ROOT/'audit/independent-lp.json',{'date':now(),'method':'Independent SciPy transportation LP vs BlocksNet/PuLP CBC','checks':evidence})

    def test_practice2_sources_unchanged(self):
        saved=json.loads((ROOT/'audit/practice2-source-hashes.json').read_text(encoding='utf-8'))
        missing=[p for p in saved['files'] if not (ROOT.parent/p).is_file()]
        if missing:
            self.skipTest('Original practice-2 sources are not part of this standalone package: '+str(len(missing)))
        changed=[p for p,h in saved['files'].items() if digest(ROOT.parent/p)!=h]
        self.assertEqual(changed,[])


class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server=make_server(0)
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True)
        cls.thread.start()
        cls.url=f'http://127.0.0.1:{cls.server.server_port}'

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close()

    def request(self,path,data=None,origin=None):
        headers={'Content-Type':'application/json'}
        if origin:headers['Origin']=origin
        request=urllib.request.Request(self.url+path,data=None if data is None else json.dumps(data).encode(),headers=headers)
        return urllib.request.urlopen(request,timeout=30)

    def test_api_scenario(self):
        with self.request('/api/bootstrap') as r:
            data=json.load(r)
        self.assertEqual(len(data['baseline']['rows']),781)
        self.assertEqual(len(data['geometry']['features']),933)
        with self.request('/api/scenario',{'additions':{'127':600}}) as r:
            scenario=json.load(r)
        self.assertEqual(scenario['summary']['capacity'],10715)
        with self.assertRaises(urllib.error.HTTPError) as error:
            self.request('/api/scenario',{'additions':{'127':-600}})
        self.assertEqual(error.exception.code,400)

    def test_local_application_boundary(self):
        with self.assertRaises(urllib.error.HTTPError) as error:
            self.request('/api/scenario',{'additions':{}},origin='https://unrelated.example')
        self.assertEqual(error.exception.code,403)
        with self.assertRaises(urllib.error.HTTPError) as error:
            self.request('/../data/blocks.csv')
        self.assertEqual(error.exception.code,404)

    def test_static_files(self):
        for path in ['/','/app.js','/style.css','/vendor/leaflet.js','/vendor/leaflet.css']:
            with self.subTest(path=path),self.request(path) as r:
                self.assertEqual(r.status,200)
                self.assertGreater(len(r.read()),100)


class SearchReportingTests(unittest.TestCase):
    def test_ties_failures_progress_and_cache(self):
        # Explicit synthetic control fixture for reporting branches; never mixed with Pskov results.
        e=object.__new__(Engine)
        e.ids=np.array([1,2,3]); e.inputs=pd.DataFrame(index=e.ids)
        e.base_summary={'deficit':10}; e.fingerprint='synthetic-control-fixture'
        failed=False
        def calculate(additions):
            i=next(iter(additions))
            if failed and i==2:
                raise RuntimeError('Искусственный сбой для проверки отчётности')
            served=2 if i in [1,3] else 1
            out=pd.DataFrame({'demand':[10,0,0],'capacity':[3,0,0],
                'demand_within':[served,0,0],'demand_left':[10-served,0,0]})
            return out,None
        e.calculate=calculate
        with tempfile.TemporaryDirectory() as directory,patch('model.RESULTS',Path(directory)):
            progress=[]
            full=e.search(3,lambda s:progress.append(s['checked']))
            self.assertEqual(full['best_ids'],[1,3])
            self.assertTrue(full['complete'])
            self.assertEqual(progress[:3],[1,2,3])
            self.assertTrue(e.search(3)['from_cache'])
            failed=True
            partial=e.search(3,force=True)
            self.assertFalse(partial['complete'])
            self.assertEqual(partial['best_ids'],[])
            self.assertEqual(partial['failed'],1)
            self.assertEqual(partial['checked'],3)


if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromModule(__import__(__name__))
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    write_json(ROOT/'audit/model-api-tests.json',{'date':now(),'tests':result.testsRun,
        'passed':result.wasSuccessful(),'failures':[str(e) for _,e in result.failures],
        'errors':[str(e) for _,e in result.errors], 'skipped':[reason for _,reason in result.skipped]})
    raise SystemExit(0 if result.wasSuccessful() else 1)
