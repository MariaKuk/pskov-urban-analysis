"""Portable baseline/scenario checks; runs on the target machine during setup."""
import importlib.metadata
import json
import platform
import subprocess
from model import Engine, ROOT, now, write_json

engine = Engine()
assert engine.base_summary['deficit'] == 12651
assert len(engine.ids) == 781
scenarios = []
for name, additions in [('A', {127: 600}), ('B', {127: 300, 295: 300}), ('C', {2: 600})]:
    value = engine.result(additions)
    assert value['summary']['deficit'] == 12051
    assert value['summary']['reduction'] == 600
    reference = json.loads((ROOT/'results'/f'scenario-{name}.json').read_text(encoding='utf-8'))
    assert value['rows'] == reference['rows'], f'Scenario {name}: quarter-level difference'
    scenarios.append({'additions': additions, 'summary': value['summary']})
report = {'date': now(), 'platform': platform.platform(), 'python': platform.python_version(),
          'machine': platform.machine(), 'versions': {k: importlib.metadata.version(k)
          for k in ['blocksnet', 'numpy', 'pandas', 'scipy', 'pulp']},
          'cbc': subprocess.run([engine.cbc, '-stop'], check=True, capture_output=True,
                                text=True).stdout,
          'fingerprint': engine.fingerprint, 'baseline': engine.base_summary,
          'scenarios': scenarios, 'passed': True}
reference = json.loads((ROOT/'results/search-600.json').read_text(encoding='utf-8'))
report['reference_best_ids'] = sorted(reference['best_ids'])
report['reference_ranking'] = [{k: row[k] for k in ['block_id','served','deficit','reduction']}
                               for row in sorted(reference['rows'],key=lambda r:r['block_id'])]
write_json(ROOT / 'audit' / 'platform-check.json', report)
print('PASS: all 781 baseline rows reproduced; A/B/C each reduce deficit by 600.', flush=True)
