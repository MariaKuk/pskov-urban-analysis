"""Portable baseline/scenario checks; runs on the target machine during setup."""
import importlib.metadata
import platform
import subprocess
from model import Engine, ROOT, now, write_json

engine = Engine()
assert engine.base_summary['deficit'] == 12651
assert len(engine.ids) == 781
scenarios = []
for additions in [{127: 600}, {127: 300, 295: 300}, {2: 600}]:
    value = engine.result(additions)
    assert value['summary']['deficit'] == 12051
    assert value['summary']['reduction'] == 600
    scenarios.append({'additions': additions, 'summary': value['summary']})
report = {'date': now(), 'platform': platform.platform(), 'python': platform.python_version(),
          'machine': platform.machine(), 'versions': {k: importlib.metadata.version(k)
          for k in ['blocksnet', 'numpy', 'pandas', 'scipy', 'pulp']},
          'cbc': subprocess.run([engine.cbc, '-stop'], check=True, capture_output=True,
                                text=True).stdout,
          'fingerprint': engine.fingerprint, 'baseline': engine.base_summary,
          'scenarios': scenarios, 'passed': True}
write_json(ROOT / 'audit' / 'platform-check.json', report)
print('PASS: all 781 baseline rows reproduced; A/B/C each reduce deficit by 600.', flush=True)
