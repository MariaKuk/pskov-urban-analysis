"""Compare the full new Windows search against the packaged research result."""
import json
from model import ROOT, now, write_json

reference=json.loads((ROOT/'audit/platform-check.json').read_text(encoding='utf-8'))
search=json.loads((ROOT/'results/search-600.json').read_text(encoding='utf-8'))
assert search['complete'] and search['checked']==781 and search['failed']==0
assert sorted(search['best_ids'])==reference['reference_best_ids']
ranking=[{k:r[k] for k in ['block_id','served','deficit','reduction']}
         for r in sorted(search['rows'],key=lambda r:r['block_id'])]
assert ranking==reference['reference_ranking']
write_json(ROOT/'audit/platform-search-check.json',{'date':now(),
    'platform':reference['platform'],'fingerprint':search['fingerprint'],
    'all_781_totals_match':True,'all_best_ids_match':True,'best_count':len(search['best_ids']),
    'passed':True})
print('PASS: all 781 placement totals and every tied best ID match the reference.',flush=True)
